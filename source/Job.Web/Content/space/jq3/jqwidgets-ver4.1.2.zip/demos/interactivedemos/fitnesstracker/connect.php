<?php
# FileName="connect.php"
$hostname = "";
$database = "";
$username = "";
$password = "";
?>